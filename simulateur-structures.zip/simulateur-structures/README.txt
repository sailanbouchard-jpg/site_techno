Simulateur de structures 2D
============================

Dossier autonome : aucune dépendance externe, aucun outil de build. Tout le
HTML/CSS/JS nécessaire est dans ce dossier.

Pour le lancer
--------------
Modules JavaScript natifs (import/export) : il faut servir le dossier via un
petit serveur local (le double-clic en file:// ne marche pas).

  1. Ouvrir un terminal dans CE dossier (simulateur-structures/)
  2. Lancer :   python -m http.server 8000
  3. Ouvrir :   http://localhost:8000/

(N'importe quel "live server" fait l'affaire. En production, build.py le copie
tel quel dans site/.)

Utilisation
-----------
On construit sur un MAILLAGE de points fixes (plus de création de nœud libre).

1. Choisir un "Type de poutre" (matériau + section) dans la barre d'outils.
2. Outil "Poutre" : cliquer DEUX points du maillage pour les relier. Une poutre
   est droite, de l'angle/longueur qu'on veut (on peut sauter des points). On ne
   peut pas poser une poutre là où une autre occupe déjà le même chemin.
3. "Ancrer / libérer" : cliquer un point pour le fixer au sol (appui).
4. "Poser un poids" : régler la masse, cliquer un point pour y suspendre une charge.
5. "Voiture"/"Camion" : cliquer une poutre cochée "Route" (dans l'inspecteur)
   pour y placer un véhicule (masse/puissance/vitesse réglables).
6. "Lancer la simulation" : la structure se déforme (flexion, flambement),
   les efforts se colorent (bleu = compression, rouge = traction), et une poutre
   trop sollicitée se rompt. "Réinitialiser" revient à l'état de conception.

Démonstrations prêtes à charger (panneau de gauche) : porte-à-faux (flexion),
colonne (flambement), pont poutre (route). "Sauvegarder" stocke une structure
(localStorage) pour la recharger plus tard.

Structure du projet
--------------------
  index.html          page hôte (canvas + barre d'outils + panneaux)
  style-config.css    couleurs/tailles/marges de l'interface
  style.css           mise en page
  js/main.js          point d'entrée (boucle d'animation)
  js/model/           données : maillage, poutres (subdivisées en segments),
                      nœuds, matériaux, démos, sauvegardes
  js/physics/         moteur : gravité, ressorts axiaux, FLEXION (ressorts
                      angulaires par différences finies), rupture, véhicules.
                      config.js = toutes les constantes réglables.
  js/render/          dessin sur le canvas (styleConfig.js = style visuel)
  js/ui/              barre d'outils, éditeur (clic maillage), inspecteur

Réglages physiques (js/physics/config.js)
-----------------------------------------
  AXIAL_STIFFNESS_DIVISOR / BENDING_STIFFNESS_DIVISOR : amplification (fixe) de
    la déformation pour bien la VOIR. La résistance (rupture) reste calculée sur
    la vraie contrainte, donc casser reste réaliste — seule la déformation est
    exagérée.
  VELOCITY_DAMPING_PER_STEP : vitesse de stabilisation (relaxation).
  RUPTURE_PERSIST_TIME : durée de surcharge avant rupture (filtre les à-coups).
  SEGMENT_TARGET_LENGTH / MIN/MAX_SEGMENTS_PER_BEAM : finesse de subdivision.

Note : quelques fichiers de l'ancienne version ne sont plus utilisés et peuvent
être supprimés (Force.js, ui/forceEditor.js, render/forceGraphRenderer.js,
model/Element.js, model/MobileLoad.js, model/testCases/).
