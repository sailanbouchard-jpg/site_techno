// ui/inspector.js
// ────────────────
// Panneau latéral : propriétés de l'élément sélectionné (poutre, point/joint,
// poids, véhicule). Lit la sélection dans state.js, affiche les champs, et
// répercute toute modification sur le modèle. Champs en lecture seule hors
// du mode édition.

import { state, MODES } from "../state.js";
import { findNodeById, findBeamById, findLoadByJointId, removeLoad, removeMobileLoad } from "../model/Structure.js";
import { getMaterialById, getBeamTypeById, BEAM_TYPES } from "../model/materials.js";
import { computeAxialStiffness } from "../model/Beam.js";
import { computeNodeEffectiveMass } from "../physics/mass.js";
import { beamUtilization } from "../physics/rupture.js";
import { populateBeamTypeSelect } from "./beamTypeSelect.js";
import { formatForce, formatMass, formatYoungModulus, formatStress, msToKmh, kmhToMs } from "../units.js";

export function renderInspector() {
  const panel = document.getElementById("inspector-panel");
  if (!panel) return;
  panel.innerHTML = "";
  const editable = state.mode === MODES.EDIT;

  if (state.selection.type === "beam") {
    const beam = findBeamById(state.structure, state.selection.id);
    if (beam) return renderBeam(panel, beam, editable);
  } else if (state.selection.type === "node") {
    const node = findNodeById(state.structure, state.selection.id);
    if (node) return renderJoint(panel, node, editable);
  } else if (state.selection.type === "load") {
    const load = state.structure.loads.find((l) => l.id === state.selection.id);
    if (load) return renderLoad(panel, load, editable);
  } else if (state.selection.type === "vehicle") {
    const v = state.structure.mobileLoads.find((x) => x.id === state.selection.id);
    if (v) return renderVehicle(panel, v, editable);
  }
  panel.textContent = "Aucune sélection.";
}

function renderBeam(panel, beam, editable) {
  title(panel, "Poutre");
  const material = getMaterialById(beam.materialId);

  // Type (matériau + section) : changer recalcule la raideur de tous les segments.
  const wrap = document.createElement("label");
  wrap.className = "inspector-field";
  wrap.textContent = "Type de poutre";
  const select = document.createElement("select");
  populateBeamTypeSelect(select);
  select.disabled = !editable;
  const current = BEAM_TYPES.find((t) => t.materialId === beam.materialId && t.thickness === beam.sectionArea);
  if (current) select.value = current.id;
  select.addEventListener("change", () => {
    const bt = getBeamTypeById(select.value);
    beam.materialId = bt.materialId;
    beam.sectionArea = bt.thickness;
    for (const segId of beam.segIds) {
      const seg = state.structure.segments.find((s) => s.id === segId);
      if (seg) seg.stiffness = computeAxialStiffness(beam.materialId, beam.sectionArea, seg.restLength);
    }
    renderInspector();
  });
  wrap.appendChild(select);
  panel.appendChild(wrap);

  if (material) {
    readonly(panel, "Module de Young", formatYoungModulus(material.youngModulus));
    readonly(panel, "Résistance traction", formatStress(material.tensileStrength));
    readonly(panel, "Résistance compression", formatStress(material.compressiveStrength));
  }
  readonly(panel, "Taux de travail max", `${Math.round(beamUtilization(state.structure, beam) * 100)} %`);
  if (beam.broken) readonly(panel, "État", "rompue");

  checkbox(panel, "Câble (traction seule)", beam.isCable, editable, (c) => { beam.isCable = c; });
  checkbox(panel, "Route (charges mobiles)", beam.isRoad, editable, (c) => { beam.isRoad = c; });
}

function renderJoint(panel, node, editable) {
  title(panel, "Point / assemblage");
  readonly(panel, "Masse effective", formatMass(computeNodeEffectiveMass(state.structure, node)));
  checkbox(panel, "Ancré au sol", node.fixed, editable, (c) => {
    node.fixed = c;
    if (c) { node.vx = 0; node.vy = 0; }
  });

  const load = findLoadByJointId(state.structure, node.id);
  if (load) {
    numberField(panel, "Poids posé (kg)", load.mass, editable, (v) => { load.mass = v; }, 1);
    if (editable) button(panel, "Retirer le poids", () => { removeLoad(state.structure, load.id); renderInspector(); });
  }
}

function renderLoad(panel, load, editable) {
  title(panel, "Poids");
  numberField(panel, "Masse (kg)", load.mass, editable, (v) => { load.mass = v; }, 1);
  if (editable) button(panel, "Supprimer", () => { removeLoad(state.structure, load.id); renderInspector(); });
}

function renderVehicle(panel, v, editable) {
  title(panel, v.presetId === "truck" ? "Camion" : "Voiture");
  numberField(panel, "Masse (kg)", v.mass, editable, (x) => { v.mass = x; }, 1);
  numberField(panel, "Puissance (ch)", v.powerHp, editable, (x) => { v.powerHp = x; }, 0);
  numberField(panel, "Vitesse (km/h)", Math.round(msToKmh(v.referenceSpeed)), editable, (x) => { v.referenceSpeed = kmhToMs(x); }, 1);
  if (editable) button(panel, "Supprimer", () => { removeMobileLoad(state.structure, v.id); renderInspector(); });
}

// ── Petits constructeurs de champs ──
function title(panel, text) {
  const h = document.createElement("h3");
  h.textContent = text;
  panel.appendChild(h);
}
function readonly(panel, label, value) {
  const w = document.createElement("div");
  w.className = "inspector-field";
  const a = document.createElement("span"); a.textContent = label;
  const b = document.createElement("span"); b.className = "inspector-readonly-value"; b.textContent = value;
  w.append(a, b); panel.appendChild(w);
}
function checkbox(panel, label, checked, editable, onChange) {
  const w = document.createElement("label");
  w.className = "inspector-field";
  const input = document.createElement("input");
  input.type = "checkbox"; input.checked = checked; input.disabled = !editable;
  input.addEventListener("change", () => onChange(input.checked));
  w.append(document.createTextNode(label), input); panel.appendChild(w);
}
function numberField(panel, label, value, editable, onChange, min) {
  const w = document.createElement("label");
  w.className = "inspector-field"; w.textContent = label;
  const input = document.createElement("input");
  input.type = "number"; input.step = "any"; input.value = value; input.disabled = !editable;
  if (min !== undefined) input.min = String(min);
  input.addEventListener("input", () => {
    let v = parseFloat(input.value);
    if (Number.isNaN(v)) return;
    if (min !== undefined) v = Math.max(min, v);
    onChange(v);
  });
  w.appendChild(input); panel.appendChild(w);
}
function button(panel, label, onClick) {
  const b = document.createElement("button");
  b.className = "inspector-button"; b.textContent = label;
  b.addEventListener("click", onClick);
  panel.appendChild(b);
}
