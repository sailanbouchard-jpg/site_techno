// ui/testCasePanel.js
// ────────────────────
// Barre latérale : démonstrations prêtes à charger + structures sauvegardées
// par l'utilisateur (localStorage). Charger remplace la structure courante et
// repasse en édition (comme "Réinitialiser"). "Sauvegarder" enregistre l'état
// courant. Aucune formule physique, aucune persistance directe ici (déléguée à
// model/savedStructures.js).

import { state, loadStructure } from "../state.js";
import { buildDemos } from "../model/demos.js";
import { listSavedStructures, saveStructure, deleteSavedStructure } from "../model/savedStructures.js";
import { refreshAfterModeChange } from "./toolbar.js";

let savedListRef = null;

export function initTestCasePanel() {
  const panel = document.getElementById("test-case-panel");
  if (!panel) return;

  const title = document.createElement("h3");
  title.textContent = "Démonstrations";
  panel.appendChild(title);

  for (const demo of buildDemos()) {
    const button = document.createElement("button");
    button.className = "test-case-button";
    button.textContent = demo.label;
    button.addEventListener("click", () => { loadStructure(demo.structure); refreshAfterModeChange(); });
    panel.appendChild(button);
  }

  const sep = document.createElement("div");
  sep.className = "test-case-separator";
  panel.appendChild(sep);

  const saveButton = document.createElement("button");
  saveButton.className = "test-case-save-button";
  saveButton.textContent = "Sauvegarder";
  saveButton.addEventListener("click", handleSave);
  panel.appendChild(saveButton);

  savedListRef = document.createElement("div");
  savedListRef.className = "saved-structure-list";
  panel.appendChild(savedListRef);
  renderSavedList();
}

function handleSave() {
  const label = window.prompt("Nom de la sauvegarde :", `Sauvegarde ${listSavedStructures().length + 1}`);
  if (!label) return;
  saveStructure(label, state.structure);
  renderSavedList();
}

function renderSavedList() {
  savedListRef.innerHTML = "";
  for (const saved of listSavedStructures()) {
    const row = document.createElement("div");
    row.className = "test-case-row";

    const load = document.createElement("button");
    load.className = "test-case-button";
    load.textContent = saved.label;
    load.addEventListener("click", () => { loadStructure(saved.structure); refreshAfterModeChange(); });
    row.appendChild(load);

    const del = document.createElement("button");
    del.className = "test-case-delete-button";
    del.textContent = "✕";
    del.title = "Supprimer cette sauvegarde";
    del.addEventListener("click", () => { deleteSavedStructure(saved.id); renderSavedList(); });
    row.appendChild(del);

    savedListRef.appendChild(row);
  }
}
