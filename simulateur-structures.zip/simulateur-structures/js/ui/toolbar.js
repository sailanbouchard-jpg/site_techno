// ui/toolbar.js
// ─────────────
// Barre d'outils : outils d'édition, type de poutre courant, masse du poids
// courant, zoom, lancement/pause/réinitialisation, affichages temps & poids.
// Met à jour state.js ; aucun dessin, aucune formule physique propre.
//
// Édition et simulation sont strictement séparées : les outils de construction
// sont désactivés hors édition ; "Réinitialiser" est l'unique retour à l'édition.

import { state, MODES, TOOLS, setTool, takeStructureSnapshot, resetToSnapshot } from "../state.js";
import { populateBeamTypeSelect } from "./beamTypeSelect.js";
import { computeStructureTotalWeight } from "../physics/mass.js";
import { formatForce, formatMass } from "../units.js";
import { ZOOM_LEVEL_MIN, ZOOM_LEVEL_MAX } from "../render/styleConfig.js";
import { renderInspector } from "./inspector.js";

let toolButtons = [];
let beamTypeSelectRef = null;
let playPauseButtonRef = null;

export function initToolbar({ onReset }) {
  toolButtons = Array.from(document.querySelectorAll("[data-tool]"));
  for (const button of toolButtons) {
    button.addEventListener("click", () => {
      if (button.disabled) return;
      setTool(button.dataset.tool);
      highlightActiveTool();
    });
  }
  initBeamTypeSelect();
  initWeightInput();
  initZoomSlider();
  initPlaybackButtons({ onReset });
  highlightActiveTool();
  refreshToolbarForMode();
}

function highlightActiveTool() {
  for (const b of toolButtons) b.classList.toggle("active", b.dataset.tool === state.currentTool);
  const canvas = document.getElementById("simulation-canvas");
  if (canvas) canvas.style.cursor = state.currentTool === TOOLS.PAN ? "grab" : "default";
}

function initBeamTypeSelect() {
  beamTypeSelectRef = document.getElementById("beam-type-select");
  if (!beamTypeSelectRef) return;
  populateBeamTypeSelect(beamTypeSelectRef);
  beamTypeSelectRef.value = state.currentBeamTypeId;
  beamTypeSelectRef.addEventListener("change", () => { state.currentBeamTypeId = beamTypeSelectRef.value; });
}

function initWeightInput() {
  const input = document.getElementById("weight-mass-input");
  if (!input) return;
  input.value = String(state.currentWeightMass);
  input.addEventListener("input", () => {
    const v = parseFloat(input.value);
    if (!Number.isNaN(v) && v > 0) state.currentWeightMass = v;
  });
}

function initZoomSlider() {
  const slider = document.getElementById("zoom-slider");
  const label = document.getElementById("zoom-value");
  if (!slider || !label) return;
  slider.min = String(ZOOM_LEVEL_MIN);
  slider.max = String(ZOOM_LEVEL_MAX);
  slider.value = String(state.zoomLevel);
  label.textContent = `×${state.zoomLevel.toFixed(1)}`;
  slider.addEventListener("input", () => {
    state.zoomLevel = parseFloat(slider.value);
    label.textContent = `×${state.zoomLevel.toFixed(1)}`;
  });
}

function initPlaybackButtons({ onReset }) {
  playPauseButtonRef = document.getElementById("play-pause-button");
  const resetButton = document.getElementById("reset-button");

  playPauseButtonRef.addEventListener("click", () => {
    if (state.mode === MODES.EDIT) {
      takeStructureSnapshot();
      state.mode = MODES.SIMULATION;
      state.isRunning = true;
      setTool(TOOLS.SELECT);
      highlightActiveTool();
    } else {
      state.isRunning = !state.isRunning;
    }
    refreshAfterModeChange();
  });

  resetButton.addEventListener("click", () => {
    resetToSnapshot();
    onReset();
    refreshAfterModeChange();
  });
}

export function refreshAfterModeChange() {
  refreshToolbarForMode();
  renderInspector();
}

function refreshToolbarForMode() {
  const editable = state.mode === MODES.EDIT;
  for (const b of toolButtons) {
    if (b.dataset.tool !== TOOLS.SELECT && b.dataset.tool !== TOOLS.PAN) b.disabled = !editable;
  }
  if (beamTypeSelectRef) beamTypeSelectRef.disabled = !editable;
  const weightInput = document.getElementById("weight-mass-input");
  if (weightInput) weightInput.disabled = !editable;
  if (playPauseButtonRef) {
    playPauseButtonRef.textContent = editable ? "Lancer la simulation" : state.isRunning ? "Pause" : "Lecture";
  }
}

export function updateTimeDisplay() {
  const d = document.getElementById("time-display");
  if (d) d.textContent = `t = ${state.simulationTime.toFixed(2)} s`;
}

export function updateStructureWeightDisplay() {
  const d = document.getElementById("structure-weight-display");
  if (d) {
    const w = computeStructureTotalWeight(state.structure);
    d.textContent = `Poids : ${formatForce(w)} (${formatMass(w / 9.81)})`;
  }
}
