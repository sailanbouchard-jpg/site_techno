// ui/structureEditor.js
// ──────────────────────
// Gère les clics/survol sur le canvas en mode édition. On ne crée plus de nœud
// libre : on CLIQUE DEUX POINTS DU MAILLAGE pour tracer une poutre (type choisi
// avant). Autres outils : ancrer un point, poser un poids, ajouter une
// voiture/un camion sur une poutre-route, supprimer, sélectionner, déplacer la vue.
//
// Aucune formule physique, aucun dessin ici. Pendant la simulation, seuls
// "Sélectionner" et "Déplacer la vue" restent actifs.

import { state, MODES, TOOLS, setSelection, clearSelection } from "../state.js";
import {
  addBeam, removeBeam, toggleAnchor, addLoad, removeLoad, findLoadByJointId,
  findNodeById, findBeamById, canAddBeam, addMobileLoad, removeMobileLoad,
} from "../model/Structure.js";
import { worldToNearestGrid } from "../model/mesh.js";
import { getVehiclePresetById } from "../model/vehiclePresets.js";
import {
  PIXELS_PER_METER, NODE_CLICK_RADIUS, ELEMENT_CLICK_TOLERANCE,
  WEIGHT_CLICK_TOLERANCE, VEHICLE_CLICK_TOLERANCE,
} from "../render/styleConfig.js";
import { worldToBasePixels, screenToWorld, screenToBasePixels } from "../render/displayTransform.js";
import { resolveVehicleDisplayPosition } from "../render/vehicleRenderer.js";

export function initStructureEditor(canvas, { onInspect }) {
  canvas.addEventListener("click", (event) => {
    if (state.mode !== MODES.EDIT && state.currentTool !== TOOLS.SELECT && state.currentTool !== TOOLS.PAN) return;
    const world = screenToWorld(...coords(canvas, event), buildView(canvas));
    // screenToBasePixels renvoie {x, y} ; les fonctions de recherche ci-dessous
    // attendent un couple [x, y] (bx[0]/bx[1]) — on convertit donc ici.
    const bp = screenToBasePixels(...coords(canvas, event), buildView(canvas));
    const bx = [bp.x, bp.y];

    switch (state.currentTool) {
      case TOOLS.ADD_BEAM: return handleAddBeam(world);
      case TOOLS.ANCHOR: return handleAnchor(bx);
      case TOOLS.ADD_WEIGHT: return handleAddWeight(bx, onInspect);
      case TOOLS.ADD_CAR: return handleAddVehicle("car", bx);
      case TOOLS.ADD_TRUCK: return handleAddVehicle("truck", bx);
      case TOOLS.DELETE: return handleDelete(bx);
      case TOOLS.SELECT: return handleSelect(bx, onInspect);
      default: return;
    }
  });

  canvas.addEventListener("mousemove", (event) => {
    if (state.mode === MODES.EDIT && state.currentTool === TOOLS.ADD_BEAM) {
      state.hoverGrid = snapGrid(screenToWorld(...coords(canvas, event), buildView(canvas)));
    } else {
      state.hoverGrid = null;
    }
  });
  canvas.addEventListener("mouseleave", () => { state.hoverGrid = null; });

  initPanDragging(canvas);
}

function buildView(canvas) {
  return { zoomLevel: state.zoomLevel, cameraX: state.cameraX, cameraY: state.cameraY, canvasWidth: canvas.width, canvasHeight: canvas.height };
}
function coords(canvas, event) {
  const rect = canvas.getBoundingClientRect();
  const sx = canvas.width / rect.width, sy = canvas.height / rect.height;
  return [(event.clientX - rect.left) * sx, (event.clientY - rect.top) * sy];
}

// Point du maillage le plus proche, seulement s'il est assez près (accrochage).
function snapGrid(world) {
  const g = worldToNearestGrid(world.x, world.y);
  return g.distance * PIXELS_PER_METER <= NODE_CLICK_RADIUS ? { i: g.i, j: g.j } : null;
}

// ── Tracer une poutre (2 points du maillage) ──
function handleAddBeam(world) {
  const grid = snapGrid(world);
  if (!grid) return;

  if (!state.pendingBeamFirstGrid) {
    state.pendingBeamFirstGrid = grid;
    return;
  }
  const a = state.pendingBeamFirstGrid;
  if (a.i === grid.i && a.j === grid.j) {
    state.pendingBeamFirstGrid = null; // re-clic sur le départ : on annule
    return;
  }
  if (canAddBeam(state.structure, a, grid).ok) {
    addBeam(state.structure, a, grid, state.currentBeamTypeId);
    state.pendingBeamFirstGrid = null;
  }
  // Si interdit (chemin occupé), on garde le point de départ : l'utilisateur
  // vise un autre point d'arrivée (l'aperçu rouge l'a prévenu).
}

function handleAnchor(bx) {
  const joint = findJointNear(bx);
  if (joint) toggleAnchor(state.structure, joint.id);
}

function handleAddWeight(bx, onInspect) {
  const joint = findJointNear(bx);
  if (!joint) return;
  const load = addLoad(state.structure, joint.id, state.currentWeightMass);
  setSelection("load", load.id);
  onInspect();
}

function handleAddVehicle(presetId, bx) {
  const beam = findRoadBeamNear(bx);
  if (!beam) return;
  const a = findNodeById(state.structure, beam.jointAId);
  const b = findNodeById(state.structure, beam.jointBId);
  const startFraction = projectFraction(bx, worldToBasePixels(a), worldToBasePixels(b));
  const preset = getVehiclePresetById(presetId);
  addMobileLoad(state.structure, {
    presetId, mass: preset.defaultMass, powerHp: preset.defaultPowerHp,
    referenceSpeed: preset.referenceSpeed, beamId: beam.id, startFraction,
  });
}

function handleDelete(bx) {
  const v = findVehicleNear(bx);
  if (v) { removeMobileLoad(state.structure, v.id); clearSelection(); return; }
  const load = findLoadNear(bx);
  if (load) { removeLoad(state.structure, load.id); clearSelection(); return; }
  const joint = findJointNear(bx);
  if (joint) {
    // Supprimer un point retire toutes les poutres qui s'y rattachent.
    for (const beam of state.structure.beams.filter((b) => b.jointAId === joint.id || b.jointBId === joint.id)) {
      removeBeam(state.structure, beam.id);
    }
    clearSelection();
    return;
  }
  const beam = findBeamNear(bx);
  if (beam) { removeBeam(state.structure, beam.id); clearSelection(); }
}

function handleSelect(bx, onInspect) {
  const v = findVehicleNear(bx);
  if (v) { setSelection("vehicle", v.id); onInspect(); return; }
  const load = findLoadNear(bx);
  if (load) { setSelection("load", load.id); onInspect(); return; }
  const joint = findJointNear(bx);
  if (joint) { setSelection("node", joint.id); onInspect(); return; }
  const beam = findBeamNear(bx);
  if (beam) { setSelection("beam", beam.id); onInspect(); return; }
  clearSelection();
  onInspect();
}

// ── Recherches (en "pixels de base") ──
function findJointNear(bx) {
  for (const n of state.structure.nodes) {
    if (n.kind !== "joint") continue;
    const p = worldToBasePixels(n);
    if (Math.hypot(p.x - bx[0], p.y - bx[1]) <= NODE_CLICK_RADIUS) return n;
  }
  return null;
}
function nearestBeam(bx, roadOnly) {
  for (const beam of state.structure.beams) {
    if (roadOnly && !beam.isRoad) continue;
    for (const segId of beam.segIds) {
      const seg = state.structure.segments.find((s) => s.id === segId);
      if (!seg) continue;
      const a = findNodeById(state.structure, seg.nodeAId), b = findNodeById(state.structure, seg.nodeBId);
      if (!a || !b) continue;
      const pa = worldToBasePixels(a), pb = worldToBasePixels(b);
      if (distSeg(bx[0], bx[1], pa.x, pa.y, pb.x, pb.y) <= ELEMENT_CLICK_TOLERANCE) return beam;
    }
  }
  return null;
}
const findBeamNear = (bx) => nearestBeam(bx, false);
const findRoadBeamNear = (bx) => nearestBeam(bx, true);

function findLoadNear(bx) {
  for (const load of state.structure.loads) {
    const node = findNodeById(state.structure, load.jointId);
    if (!node) continue;
    const p = worldToBasePixels(node);
    if (Math.hypot(p.x - bx[0], p.y - bx[1] - 12) <= WEIGHT_CLICK_TOLERANCE) return load;
  }
  return null;
}
function findVehicleNear(bx) {
  for (const v of state.structure.mobileLoads) {
    const pos = resolveVehicleDisplayPosition(v, state.structure);
    if (!pos) continue;
    if (Math.hypot(pos.x - bx[0], pos.y - bx[1]) <= VEHICLE_CLICK_TOLERANCE) return v;
  }
  return null;
}

function projectFraction(bx, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy;
  if (l2 === 0) return 0.5;
  return Math.max(0, Math.min(1, ((bx[0] - a.x) * dx + (bx[1] - a.y) * dy) / l2));
}
function distSeg(px, py, ax, ay, bx2, by) {
  const dx = bx2 - ax, dy = by - ay, l2 = dx * dx + dy * dy;
  if (l2 === 0) return Math.hypot(px - ax, py - ay);
  let t = ((px - ax) * dx + (py - ay) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

// ── Déplacement de la vue (glisser) ──
function initPanDragging(canvas) {
  let panning = false, lx = 0, ly = 0;
  canvas.addEventListener("mousedown", (e) => {
    if (state.currentTool !== TOOLS.PAN) return;
    panning = true; [lx, ly] = coords(canvas, e); canvas.style.cursor = "grabbing";
  });
  window.addEventListener("mousemove", (e) => {
    if (!panning) return;
    const [x, y] = coords(canvas, e);
    const scale = PIXELS_PER_METER * state.zoomLevel;
    state.cameraX -= (x - lx) / scale; state.cameraY -= (y - ly) / scale;
    lx = x; ly = y;
  });
  window.addEventListener("mouseup", () => {
    if (!panning) return;
    panning = false; canvas.style.cursor = state.currentTool === TOOLS.PAN ? "grab" : "default";
  });
}
