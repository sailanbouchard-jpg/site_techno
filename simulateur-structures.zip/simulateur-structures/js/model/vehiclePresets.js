// model/vehiclePresets.js
// ────────────────────────
// Rôle : catalogue des charges mobiles proposées à l'utilisateur (boutons
// "Ajouter une voiture"/"Ajouter un camion" de la barre d'outils). PURES
// DONNÉES, aucun calcul physique — voir physics/vehicleMotion.js.
//
// referenceSpeed est en m/s (100 km/h ≈ 27,78 m/s ; 80 km/h ≈ 22,22 m/s) :
// c'est la vitesse de croisière atteinte sur une route plate à pleine
// puissance (voir physics/vehicleMotion.js pour la justification).
//
// Ne doit PAS contenir : de logique de calcul (-> model/MobileLoad.js, physics/).
// Dépendances : aucune.

export const VEHICLE_PRESETS = [
  { id: "car", label: "Voiture", defaultMass: 1500, defaultPowerHp: 150, referenceSpeed: 27.78 },
  { id: "truck", label: "Camion", defaultMass: 15000, defaultPowerHp: 400, referenceSpeed: 22.22 },
];

export function getVehiclePresetById(presetId) {
  return VEHICLE_PRESETS.find((preset) => preset.id === presetId) || null;
}
