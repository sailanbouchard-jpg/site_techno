// model/demos.js
// ──────────────
// Quelques structures de DÉMONSTRATION prêtes à charger (même forme que les
// sauvegardes : { id, label, structure }). Construites avec les fonctions de
// Structure.js, donc toujours cohérentes avec le modèle courant. Servent de
// point de départ — l'enseignant en fera de "vrais" niveaux plus tard.

import { createStructure, addBeam, toggleAnchor, addLoad } from "./Structure.js";

function cantilever() {
  const s = createStructure();
  const b = addBeam(s, { i: 2, j: 5 }, { i: 8, j: 5 }, "wood-large");
  toggleAnchor(s, b.jointAId); // base encastrée → fléchit sous son poids
  return s;
}

function column() {
  const s = createStructure();
  const b = addBeam(s, { i: 10, j: 11 }, { i: 10, j: 5 }, "steel-thin");
  toggleAnchor(s, b.jointAId);     // pied ancré
  addLoad(s, b.jointBId, 30000);   // 30 t en tête → flambe
  return s;
}

function beamBridge() {
  const s = createStructure();
  // Tablier (route) entre deux appuis ancrés ; un camion le fera fléchir.
  const deck = addBeam(s, { i: 3, j: 7 }, { i: 15, j: 7 }, "steel-large", { isRoad: true });
  toggleAnchor(s, deck.jointAId);
  toggleAnchor(s, deck.jointBId);
  return s;
}

export function buildDemos() {
  return [
    { id: "demo-cantilever", label: "Porte-à-faux (flexion)", structure: cantilever() },
    { id: "demo-column", label: "Colonne (flambement)", structure: column() },
    { id: "demo-bridge", label: "Pont poutre (route)", structure: beamBridge() },
  ];
}
