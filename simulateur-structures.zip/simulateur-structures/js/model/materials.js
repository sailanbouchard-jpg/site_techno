// model/materials.js
// ──────────────────
// Catalogue des matériaux ET des "types de poutres" (matériau × épaisseur).
// PURES DONNÉES + petites fonctions de recherche. Pour ajouter un matériau ou
// un type : ajouter une ligne, c'est tout.
//
// youngModulus / tensileStrength / compressiveStrength en Pascals (Pa),
// density en kg/m³. Valeurs d'ordre Eurocode, arrondies "pédago".
//
// L'ASYMÉTRIE traction / compression est volontaire et porteuse de sens :
//  - l'acier résiste autant dans les deux sens ;
//  - le béton encaisse beaucoup en compression mais très peu en traction
//    (d'où le béton ARMÉ dans la vraie vie) ;
//  - le bois est intermédiaire.
// C'est cette asymétrie qui, en compression, oriente aussi le flambement.

export const MATERIALS = [
  { id: "wood", name: "Bois", youngModulus: 11e9, density: 500, tensileStrength: 40e6, compressiveStrength: 24e6, color: "#a0522d" },
  { id: "steel", name: "Acier", youngModulus: 210e9, density: 7850, tensileStrength: 235e6, compressiveStrength: 235e6, color: "#7d7d86" },
  { id: "concrete", name: "Béton", youngModulus: 30e9, density: 2500, tensileStrength: 15e6, compressiveStrength: 30e6, color: "#9a978c" },
];

export function getMaterialById(materialId) {
  return MATERIALS.find((material) => material.id === materialId) || null;
}

// "Types de poutres" proposés à l'utilisateur : matériau + épaisseur. Convention
// (héritée du projet) : profondeur conventionnelle de 1 m, donc aire de section
// (m²) = épaisseur (m). On ne règle plus une section libre : on choisit un type.
export const BEAM_TYPES = [
  { id: "wood-thin", materialId: "wood", label: "Bois fin", thickness: 0.06 },
  { id: "wood-large", materialId: "wood", label: "Bois large", thickness: 0.16 },
  { id: "steel-thin", materialId: "steel", label: "Acier fin", thickness: 0.03 },
  { id: "steel-large", materialId: "steel", label: "Acier large", thickness: 0.08 },
  { id: "concrete-thin", materialId: "concrete", label: "Béton fin", thickness: 0.12 },
  { id: "concrete-large", materialId: "concrete", label: "Béton large", thickness: 0.25 },
];

export function getBeamTypeById(beamTypeId) {
  return BEAM_TYPES.find((beamType) => beamType.id === beamTypeId) || null;
}
