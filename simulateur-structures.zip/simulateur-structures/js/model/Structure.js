// model/Structure.js
// ──────────────────
// Conteneur central : nœuds, poutres (macro), segments (sous-éléments),
// charges ponctuelles (poids posés), charges mobiles (véhicules). C'est le
// SEUL fichier qui modifie la TOPOLOGIE (créer/supprimer poutres, ancrer,
// scinder une poutre rompue). Aucune formule physique, aucun dessin ici.
//
// Modèle de données :
//   node    : { id, x, y, vx, vy, fixed, kind:"joint"|"inner", gridI, gridJ, restX, restY }
//   beam    : { id, materialId, sectionArea, gridA, gridB, jointAId, jointBId,
//               nodeIds:[...ordonnés...], segIds:[...], isRoad, isCable, broken }
//   segment : { id, beamId, nodeAId, nodeBId, restLength, stiffness }
//   load    : { id, jointId, mass }   (poids suspendu à un point)
//   vehicle : voir model/MobileLoad.js

import { createNode } from "./Node.js";
import { getMaterialById, getBeamTypeById } from "./materials.js";
import { gridToWorld, isInBounds, beamsOverlapOnPath } from "./mesh.js";
import { buildBeamGeometry, computeAxialStiffness } from "./Beam.js";

let nextNumericId = 1;
function generateId(prefix) {
  const id = `${prefix}-${nextNumericId}`;
  nextNumericId += 1;
  return id;
}

export function createStructure() {
  return { nodes: [], beams: [], segments: [], loads: [], mobileLoads: [] };
}

// ── Recherches ──
export function findNodeById(structure, id) {
  return structure.nodes.find((n) => n.id === id) || null;
}
export function findBeamById(structure, id) {
  return structure.beams.find((b) => b.id === id) || null;
}
export function findSegmentById(structure, id) {
  return structure.segments.find((s) => s.id === id) || null;
}
export function findJointAtGrid(structure, i, j) {
  return structure.nodes.find((n) => n.kind === "joint" && n.gridI === i && n.gridJ === j) || null;
}
export function findLoadByJointId(structure, jointId) {
  return structure.loads.find((l) => l.jointId === jointId) || null;
}
export function segmentsConnectedToNode(structure, nodeId) {
  return structure.segments.filter((s) => s.nodeAId === nodeId || s.nodeBId === nodeId);
}
// Combien de poutres (macro) partagent ce joint : ≥ 2 → c'est un assemblage,
// le pivot y résiste élastiquement (voir physics/bending.js).
export function jointBeamCount(structure, jointId) {
  let count = 0;
  for (const beam of structure.beams) {
    if (beam.jointAId === jointId || beam.jointBId === jointId) count += 1;
  }
  return count;
}

// ── Création de poutre ──
// Peut-on relier ces deux points du maillage ? Non si c'est le même point, s'il
// sort du maillage, ou si une poutre occupe déjà le même chemin (colinéaire et
// recouvrant — voir mesh.js::beamsOverlapOnPath).
export function canAddBeam(structure, a, b) {
  if (a.i === b.i && a.j === b.j) return { ok: false, reason: "même point" };
  if (!isInBounds(a.i, a.j) || !isInBounds(b.i, b.j)) return { ok: false, reason: "hors maillage" };
  for (const beam of structure.beams) {
    if (beamsOverlapOnPath(a, b, beam.gridA, beam.gridB)) {
      return { ok: false, reason: "une poutre occupe déjà ce chemin" };
    }
  }
  return { ok: true };
}

function ensureJoint(structure, grid) {
  const existing = findJointAtGrid(structure, grid.i, grid.j);
  if (existing) return existing;
  const world = gridToWorld(grid.i, grid.j);
  const node = createNode({ id: generateId("node"), x: world.x, y: world.y, kind: "joint", gridI: grid.i, gridJ: grid.j });
  structure.nodes.push(node);
  return node;
}

function addInnerNode(structure, x, y) {
  const node = createNode({ id: generateId("node"), x, y, kind: "inner" });
  structure.nodes.push(node);
  return node;
}

function addSegment(structure, beamId, nodeAId, nodeBId, restLength, stiffness) {
  const seg = { id: generateId("seg"), beamId, nodeAId, nodeBId, restLength, stiffness };
  structure.segments.push(seg);
  return seg;
}

// Crée une poutre entre deux points du maillage `a` et `b` (indices), du type
// donné. Réutilise les joints déjà présents, crée les nœuds internes de
// subdivision et les segments. Suppose canAddBeam() déjà vérifié.
export function addBeam(structure, a, b, beamTypeId, { isRoad = false, isCable = false } = {}) {
  const beamType = getBeamTypeById(beamTypeId);
  const materialId = beamType.materialId;
  const sectionArea = beamType.thickness;

  const jointA = ensureJoint(structure, a);
  const jointB = ensureJoint(structure, b);
  const geom = buildBeamGeometry(jointA.x, jointA.y, jointB.x, jointB.y, materialId, sectionArea);

  const nodeIds = [jointA.id];
  for (const pos of geom.innerPositions) {
    nodeIds.push(addInnerNode(structure, pos.x, pos.y).id);
  }
  nodeIds.push(jointB.id);

  const beamId = generateId("beam");
  const segIds = [];
  for (let k = 0; k < nodeIds.length - 1; k++) {
    segIds.push(addSegment(structure, beamId, nodeIds[k], nodeIds[k + 1], geom.segRestLength, geom.segStiffness).id);
  }

  const beam = {
    id: beamId,
    materialId,
    sectionArea,
    gridA: { i: a.i, j: a.j },
    gridB: { i: b.i, j: b.j },
    jointAId: jointA.id,
    jointBId: jointB.id,
    nodeIds,
    segIds,
    isRoad,
    isCable,
    broken: false,
  };
  structure.beams.push(beam);
  return beam;
}

// ── Suppression ──
function removeNodeById(structure, nodeId) {
  structure.nodes = structure.nodes.filter((n) => n.id !== nodeId);
  structure.loads = structure.loads.filter((l) => l.jointId !== nodeId);
}

export function removeBeam(structure, beamId) {
  const beam = findBeamById(structure, beamId);
  if (!beam) return;

  // Segments + nœuds internes de cette poutre disparaissent avec elle.
  const innerIds = beam.nodeIds.filter((id) => id !== beam.jointAId && id !== beam.jointBId);
  structure.segments = structure.segments.filter((s) => s.beamId !== beamId);
  structure.beams = structure.beams.filter((b) => b.id !== beamId);
  for (const id of innerIds) removeNodeById(structure, id);

  // Charges mobiles qui roulaient sur cette poutre : supprimées.
  structure.mobileLoads = structure.mobileLoads.filter((v) => v.beamId !== beamId);

  // Joints devenus orphelins (plus aucune poutre) : retirés (avec leur poids).
  for (const jointId of [beam.jointAId, beam.jointBId]) {
    if (jointBeamCount(structure, jointId) === 0) removeNodeById(structure, jointId);
  }
}

// ── Ancrage / charges ponctuelles ──
export function toggleAnchor(structure, jointId) {
  const node = findNodeById(structure, jointId);
  if (!node || node.kind !== "joint") return;
  node.fixed = !node.fixed;
  if (node.fixed) {
    node.vx = 0;
    node.vy = 0;
  }
}

export function addLoad(structure, jointId, mass) {
  const existing = findLoadByJointId(structure, jointId);
  if (existing) {
    existing.mass = mass;
    return existing;
  }
  const load = { id: generateId("load"), jointId, mass };
  structure.loads.push(load);
  return load;
}

export function removeLoad(structure, loadId) {
  structure.loads = structure.loads.filter((l) => l.id !== loadId);
}

// ── Charges mobiles (véhicules) ──
export function addMobileLoad(structure, { presetId, mass, powerHp, referenceSpeed, beamId, startFraction = 0.5 }) {
  const vehicle = {
    id: generateId("vehicle"),
    presetId,
    mass,
    powerHp,
    referenceSpeed,
    beamId,
    distanceAlongBeam: 0, // recalculé au lancement depuis startFraction
    startFraction,
    pathVelocity: 0,
    state: "onRoad",
  };
  structure.mobileLoads.push(vehicle);
  return vehicle;
}

export function removeMobileLoad(structure, vehicleId) {
  structure.mobileLoads = structure.mobileLoads.filter((v) => v.id !== vehicleId);
}

// ── Rupture : scinder une poutre à un nœud interne ──
// La poutre se casse au nœud interne d'indice `breakIndex` (1..len-2) : on
// duplique ce nœud (les deux morceaux peuvent dès lors s'écarter), on répartit
// les nœuds en deux chaînes, et on reconstruit une poutre par chaîne. Les
// joints d'extrémité gardent leur identité (les morceaux restent accrochés à
// la structure par leurs bouts). Les joints, eux, ne se brisent jamais.
export function splitBeam(structure, beamId, breakIndex) {
  const beam = findBeamById(structure, beamId);
  if (!beam) return;
  const ids = beam.nodeIds;
  if (breakIndex < 1 || breakIndex > ids.length - 2) return;

  const breakNode = findNodeById(structure, ids[breakIndex]);
  const duplicate = addInnerNode(structure, breakNode.x, breakNode.y);
  duplicate.vx = breakNode.vx;
  duplicate.vy = breakNode.vy;

  const firstChain = ids.slice(0, breakIndex + 1); // ... -> breakNode
  const secondChain = [duplicate.id, ...ids.slice(breakIndex + 1)]; // duplicate -> ...

  // On retire l'ancienne poutre (segments compris) puis on en recrée deux.
  structure.segments = structure.segments.filter((s) => s.beamId !== beamId);
  structure.beams = structure.beams.filter((b) => b.id !== beamId);

  rebuildBeamFromChain(structure, beam, firstChain, true);
  rebuildBeamFromChain(structure, beam, secondChain, true);

  // Une charge mobile sur la poutre cassée tombe (simplification : on la retire).
  structure.mobileLoads = structure.mobileLoads.filter((v) => v.beamId !== beamId);
}

function rebuildBeamFromChain(structure, oldBeam, chainNodeIds, broken) {
  if (chainNodeIds.length < 2) return null;
  const beamId = generateId("beam");
  const segIds = [];
  for (let k = 0; k < chainNodeIds.length - 1; k++) {
    const a = findNodeById(structure, chainNodeIds[k]);
    const b = findNodeById(structure, chainNodeIds[k + 1]);
    const restLength = Math.hypot(b.restX - a.restX, b.restY - a.restY) || 0.0001;
    const stiffness = computeAxialStiffness(oldBeam.materialId, oldBeam.sectionArea, restLength);
    segIds.push(addSegment(structure, beamId, a.id, b.id, restLength, stiffness).id);
  }
  const aNode = findNodeById(structure, chainNodeIds[0]);
  const bNode = findNodeById(structure, chainNodeIds[chainNodeIds.length - 1]);
  const beam = {
    id: beamId,
    materialId: oldBeam.materialId,
    sectionArea: oldBeam.sectionArea,
    gridA: aNode.kind === "joint" ? { i: aNode.gridI, j: aNode.gridJ } : null,
    gridB: bNode.kind === "joint" ? { i: bNode.gridI, j: bNode.gridJ } : null,
    jointAId: aNode.kind === "joint" ? aNode.id : null,
    jointBId: bNode.kind === "joint" ? bNode.id : null,
    nodeIds: [...chainNodeIds],
    segIds,
    isRoad: false, // un morceau rompu ne porte plus de route
    isCable: oldBeam.isCable,
    broken,
  };
  structure.beams.push(beam);
  return beam;
}
// fin Structure.js
