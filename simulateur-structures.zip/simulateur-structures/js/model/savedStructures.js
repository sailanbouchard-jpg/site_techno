// model/savedStructures.js
// ─────────────────────────
// Rôle : sauvegarder/lister/supprimer des structures construites par
// l'utilisateur, depuis le panneau "Configurations de test"
// (ui/testCasePanel.js), en les persistant dans localStorage — seul
// mécanisme de persistance du projet pour l'instant (pas de backend, pas de
// compte élève, voir aussi model/Structure.js::exportStructure).
//
// Une sauvegarde a EXACTEMENT la même forme qu'une entrée de
// model/testCases/index.js::TEST_CASES ({ id, label, structure }), pour que
// ui/testCasePanel.js puisse la charger avec la MÊME fonction
// (state.js::loadTestCase) sans distinguer les deux cas.
//
// Ne doit PAS contenir : de formule physique, de code de dessin, de gestion
// d'événements DOM (-> ui/testCasePanel.js, qui appelle ces fonctions).
// Dépendances : aucune (API navigateur localStorage uniquement).

const STORAGE_KEY = "simulateur-structures:savedStructures";

// Compteur simple pour générer des ids lisibles ("saved-1", "saved-2"...),
// dans le même esprit que model/Structure.js::generateId — pas besoin d'UUID
// pour ce projet. Recalé au démarrage sur le plus grand id déjà présent dans
// localStorage (voir listSavedStructures), pour ne jamais réutiliser un id
// après un rechargement de page.
let nextSavedId = 1;

export function listSavedStructures() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return [];

  let saved;
  try {
    saved = JSON.parse(raw);
  } catch {
    // Garde-fou : une valeur corrompue dans localStorage ne doit jamais
    // empêcher le reste de l'application de fonctionner.
    return [];
  }
  if (!Array.isArray(saved)) return [];

  for (const entry of saved) {
    const numericPart = parseInt(String(entry.id).replace("saved-", ""), 10);
    if (!Number.isNaN(numericPart) && numericPart >= nextSavedId) {
      nextSavedId = numericPart + 1;
    }
  }
  return saved;
}

function persist(savedStructures) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(savedStructures));
}

// Sauvegarde un CLONE de `structure` sous le nom `label` (jamais une
// référence partagée — même précaution que state.js::loadTestCase, sinon
// continuer à modifier la structure courante corromprait la sauvegarde).
export function saveStructure(label, structure) {
  const saved = listSavedStructures();
  const entry = {
    id: `saved-${nextSavedId}`,
    label,
    structure: structuredClone(structure),
  };
  nextSavedId += 1;
  saved.push(entry);
  persist(saved);
  return entry;
}

export function deleteSavedStructure(id) {
  const saved = listSavedStructures().filter((entry) => entry.id !== id);
  persist(saved);
}
