// physics/mass.js
// ───────────────
// Masse "effective" d'un nœud = sa part de la masse des poutres connectées
// (matériau × section × longueur, répartie moitié-moitié sur les deux nœuds de
// chaque segment). Sert à la fois d'INERTIE pour l'intégration ET de poids
// PROPRE (× g) dans loads.js.
//
// IMPORTANT : un poids POSÉ par l'utilisateur n'est PAS ajouté ici. Il est
// appliqué comme une FORCE dans loads.js (mass × g), pas comme une inertie —
// sinon l'accélération vaudrait g quelle que soit la charge (F=m·a → a=g) et la
// structure ne "sentirait" jamais une surcharge, donc ne romprait jamais.

import { findBeamById, segmentsConnectedToNode } from "../model/Structure.js";
import { getMaterialById } from "../model/materials.js";
import { MIN_NODE_MASS, GRAVITY_ACCELERATION } from "./config.js";

function segmentOwnMass(structure, segment) {
  const beam = findBeamById(structure, segment.beamId);
  if (!beam) return 0;
  const material = getMaterialById(beam.materialId);
  if (!material) return 0;
  return material.density * beam.sectionArea * segment.restLength;
}

export function computeNodeEffectiveMass(structure, node) {
  let totalMass = 0;
  for (const segment of segmentsConnectedToNode(structure, node.id)) {
    totalMass += segmentOwnMass(structure, segment) / 2;
  }
  return Math.max(totalMass, MIN_NODE_MASS);
}

// Poids total (N) de la structure : poutres + poids posés. Pour l'affichage.
export function computeStructureTotalWeight(structure) {
  let mass = 0;
  for (const segment of structure.segments) mass += segmentOwnMass(structure, segment);
  for (const load of structure.loads) mass += load.mass;
  return mass * GRAVITY_ACCELERATION;
}
