// physics/rupture.js
// ──────────────────
// Une poutre peut se rompre en TRACTION, en COMPRESSION ou en FLEXION, à
// L'ENDROIT le plus sollicité. La RÉSISTANCE est calculée sur la vraie
// contrainte (force / section, moment / module), indépendamment du gain de
// déformation : casser reste "vrai" même si la déformation est exagérée.
//
// Le flambement, lui, n'est pas un seuil ici : il ÉMERGE de la dynamique
// (compression + ressorts angulaires + imperfection, voir bending.js). Une
// poutre flambée finit souvent par rompre en flexion à mi-portée — ce que
// détecte la partie "flexion" ci-dessous.
//
// Les joints/points ne se brisent jamais (comportement élastique).

import { getMaterialById } from "../model/materials.js";
import { findNodeById, splitBeam } from "../model/Structure.js";
import { computeSegmentForce } from "./springForces.js";
import { bendingStiffness, turningAngle } from "./bending.js";
import { RUPTURE_PERSIST_TIME } from "./config.js";

// Taux de travail (≥1 = rompt) d'un segment en axial : contrainte / résistance,
// résistance différente en traction et en compression (asymétrie matériau).
function segmentAxialUtilization(structure, beam, segment, material) {
  const a = findNodeById(structure, segment.nodeAId);
  const b = findNodeById(structure, segment.nodeBId);
  const { magnitude } = computeSegmentForce(a, b, segment, beam.isCable);
  const stress = Math.abs(magnitude) / beam.sectionArea;
  const limit = magnitude >= 0 ? material.tensileStrength : material.compressiveStrength;
  return limit > 0 ? stress / limit : 0;
}

// Taux de travail d'une charnière en flexion : contrainte de fibre extrême
// σ = M·(t/2) / I = 6M / t²  (t = épaisseur = sectionArea), comparée à la
// résistance en traction (la fibre tendue lâche en premier).
function hingeBendingUtilization(structure, beam, i, kTheta, material) {
  const p0 = findNodeById(structure, beam.nodeIds[i - 1]);
  const p1 = findNodeById(structure, beam.nodeIds[i]);
  const p2 = findNodeById(structure, beam.nodeIds[i + 1]);
  const moment = Math.abs(kTheta * turningAngle(p0, p1, p2));
  const stress = (6 * moment) / (beam.sectionArea * beam.sectionArea);
  return material.tensileStrength > 0 ? stress / material.tensileStrength : 0;
}

// Endroit le plus sollicité d'une poutre : { util, breakIndex } (index de nœud
// interne où scinder). breakIndex null si la poutre est trop courte pour casser.
function worstLocation(structure, beam) {
  const material = getMaterialById(beam.materialId);
  const ids = beam.nodeIds;
  if (!material || ids.length < 3) return { util: 0, breakIndex: null };

  let best = { util: 0, breakIndex: null };

  // Axial, segment par segment.
  for (let k = 0; k < beam.segIds.length; k++) {
    const segment = structure.segments.find((s) => s.id === beam.segIds[k]);
    if (!segment) continue;
    const util = segmentAxialUtilization(structure, beam, segment, material);
    const breakIndex = Math.min(Math.max(k, 1), ids.length - 2);
    if (util > best.util) best = { util, breakIndex };
  }

  // Flexion, charnière par charnière.
  const seg0 = structure.segments.find((s) => s.id === beam.segIds[0]);
  const kTheta = bendingStiffness(beam.materialId, beam.sectionArea, seg0 ? seg0.restLength : 1);
  for (let i = 1; i < ids.length - 1; i++) {
    const util = hingeBendingUtilization(structure, beam, i, kTheta, material);
    if (util > best.util) best = { util, breakIndex: i };
  }

  return best;
}

// Taux de travail max d'une poutre (pour l'affichage éventuel d'un %).
export function beamUtilization(structure, beam) {
  return worstLocation(structure, beam).util;
}

// Parcourt toutes les poutres et casse celles qui dépassent leur limite, à leur
// point le plus sollicité. Les ruptures sont COLLECTÉES puis appliquées après
// le parcours (splitBeam modifie la liste des poutres). Renvoie le nombre de
// ruptures de ce pas.
export function applyRuptures(structure, dt) {
  const toBreak = [];
  for (const beam of structure.beams) {
    const { util, breakIndex } = worstLocation(structure, beam);
    if (util > 1 && breakIndex !== null) {
      // Anti-pic : on n'accumule le "temps de surcharge" que tant qu'on dépasse
      // la limite ; il faut tenir RUPTURE_PERSIST_TIME pour casser (voir config).
      beam.overTime = (beam.overTime || 0) + dt;
      if (beam.overTime >= RUPTURE_PERSIST_TIME) toBreak.push({ beamId: beam.id, breakIndex });
    } else {
      beam.overTime = 0;
    }
  }
  for (const { beamId, breakIndex } of toBreak) splitBeam(structure, beamId, breakIndex);
  return toBreak.length;
}
