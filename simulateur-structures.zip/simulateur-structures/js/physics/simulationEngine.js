// physics/simulationEngine.js
// ───────────────────────────
// SEUL point d'entrée physique. Un pas complet : forces externes (gravité +
// charges mobiles) → forces axiales des segments → forces angulaires (flexion)
// → intégration des nœuds libres → avance des charges mobiles → ruptures.
//
// Les ruptures sont appliquées en TOUT DERNIER (elles changent la topologie),
// jamais pendant le calcul des forces : le résultat ne dépend pas de l'ordre
// de parcours.

import { findNodeById, findBeamById } from "../model/Structure.js";
import { getExternalForce, addMobileLoadWeights } from "./loads.js";
import { computeSegmentForce } from "./springForces.js";
import { applyBeamBending } from "./bending.js";
import { integrateNode } from "./integrator.js";
import { computeNodeEffectiveMass } from "./mass.js";
import { applyRuptures } from "./rupture.js";
import { advanceMobileLoad } from "./vehicleMotion.js";

export function step(structure, dt, currentTime) {
  // 1. Forces externes (gravité) sur chaque nœud LIBRE.
  const forces = new Map();
  for (const node of structure.nodes) {
    if (node.fixed) continue;
    forces.set(node.id, getExternalForce(structure, node, currentTime));
  }
  addMobileLoadWeights(forces, structure, currentTime);

  // 2. Forces axiales des segments.
  for (const segment of structure.segments) {
    const nodeA = findNodeById(structure, segment.nodeAId);
    const nodeB = findNodeById(structure, segment.nodeBId);
    if (!nodeA || !nodeB) continue;
    const beam = findBeamById(structure, segment.beamId);
    const isCable = beam ? beam.isCable : false;
    const { forceOnA, forceOnB } = computeSegmentForce(nodeA, nodeB, segment, isCable);
    if (!nodeA.fixed) {
      const f = forces.get(nodeA.id);
      f.fx += forceOnA.fx;
      f.fy += forceOnA.fy;
    }
    if (!nodeB.fixed) {
      const f = forces.get(nodeB.id);
      f.fx += forceOnB.fx;
      f.fy += forceOnB.fy;
    }
  }

  // 3. Forces angulaires (flexion) de chaque poutre.
  for (const beam of structure.beams) {
    applyBeamBending(structure, beam, forces);
  }

  // 4. Intégration des nœuds libres.
  for (const node of structure.nodes) {
    if (node.fixed) continue;
    const mass = computeNodeEffectiveMass(structure, node);
    integrateNode(node, forces.get(node.id), mass, dt);
  }

  // 5. Avance des charges mobiles.
  for (const vehicle of structure.mobileLoads) {
    advanceMobileLoad(vehicle, structure, dt);
  }

  // 6. Ruptures (en dernier : changent la topologie).
  applyRuptures(structure, dt);
}
