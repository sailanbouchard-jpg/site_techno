// physics/vehicleMotion.js
// ────────────────────────
// Déplacement d'une charge mobile le long d'une poutre marquée "route". La
// poutre étant subdivisée, le véhicule avance le long de la CHAÎNE de nœuds
// (segments) de la poutre, repéré par sa distance parcourue depuis le début.
//
// getCurrentRoadSegment() rend le segment courant (ses deux nœuds + la fraction
// 0..1 dessus) : partagé par le poids (loads.js) et le dessin (vehicleRenderer.js).

import { findBeamById, findNodeById } from "../model/Structure.js";
import { WATTS_PER_HORSEPOWER, MAX_VEHICLE_SPEED, ROLLING_RESISTANCE, GRAVITY_ACCELERATION } from "./config.js";

function beamTotalLength(beam, structure) {
  let total = 0;
  for (const segId of beam.segIds) {
    const seg = structure.segments.find((s) => s.id === segId);
    if (seg) total += seg.restLength;
  }
  return total;
}

// Place le véhicule à sa fraction de départ la première fois qu'on en a besoin
// (la longueur de la poutre n'est connue qu'ici).
function ensurePlaced(vehicle, structure, beam) {
  if (vehicle.placed) return;
  vehicle.distanceAlongBeam = vehicle.startFraction * beamTotalLength(beam, structure);
  vehicle.placed = true;
}

export function getCurrentRoadSegment(vehicle, structure) {
  const beam = findBeamById(structure, vehicle.beamId);
  if (!beam) return {};
  ensurePlaced(vehicle, structure, beam);

  let remaining = vehicle.distanceAlongBeam;
  for (const segId of beam.segIds) {
    const seg = structure.segments.find((s) => s.id === segId);
    if (!seg) continue;
    if (remaining <= seg.restLength || segId === beam.segIds[beam.segIds.length - 1]) {
      const fraction = seg.restLength === 0 ? 0 : Math.max(0, Math.min(1, remaining / seg.restLength));
      return { nodeA: findNodeById(structure, seg.nodeAId), nodeB: findNodeById(structure, seg.nodeBId), fraction };
    }
    remaining -= seg.restLength;
  }
  return {};
}

export function advanceMobileLoad(vehicle, structure, dt) {
  const beam = findBeamById(structure, vehicle.beamId);
  if (!beam) {
    vehicle.state = "fallenOff";
    return;
  }
  ensurePlaced(vehicle, structure, beam);

  const total = beamTotalLength(beam, structure);
  const power = vehicle.powerHp * WATTS_PER_HORSEPOWER;
  const v = Math.max(vehicle.pathVelocity, 0.5); // évite la division par zéro
  const tractive = power / v;
  const rolling = ROLLING_RESISTANCE * vehicle.mass * GRAVITY_ACCELERATION;
  const accel = (tractive - rolling) / vehicle.mass;

  const target = Math.min(vehicle.referenceSpeed, MAX_VEHICLE_SPEED);
  vehicle.pathVelocity = Math.max(0, Math.min(target, vehicle.pathVelocity + accel * dt));
  vehicle.distanceAlongBeam += vehicle.pathVelocity * dt;

  if (vehicle.distanceAlongBeam >= total) {
    vehicle.distanceAlongBeam = total;
    vehicle.pathVelocity = 0; // arrivé au bout
  }
}
