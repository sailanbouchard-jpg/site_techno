// physics/bending.js
// ──────────────────
// La FLEXION. Des RESSORTS ANGULAIRES pénalisent le changement d'angle :
//  1. charnière interne : entre deux segments consécutifs d'une poutre (repos
//     droit) → rigidité de flexion E·I, et FLAMBEMENT émergent sous compression ;
//  2. pivot d'extrémité : à un nœud d'assemblage (ancré, ou partagé par ≥2
//     poutres), résiste à la rotation du segment d'extrémité → encastrement
//     élastique (fait fléchir un porte-à-faux dès la base).
//
// La force de chaque ressort est le GRADIENT de son énergie ½·k·angle²,
// calculé par DIFFÉRENCES FINIES : c'est exact (signe garanti, énergie qui ne
// peut que décroître avec l'amortissement) et robuste, là où une formule
// analytique mal signée injecterait de l'énergie. Le coût reste local (quelques
// évaluations d'angle par charnière), négligeable aux tailles de ce projet.

import { BENDING_STIFFNESS_DIVISOR, JOINT_STIFFNESS_FACTOR } from "./config.js";
import { getMaterialById } from "../model/materials.js";
import { findNodeById, jointBeamCount } from "../model/Structure.js";

const FD_STEP = 1e-6; // pas de différence finie (m)

// Raideur d'une charnière (N·m/rad) : E·I / L, assouplie par le diviseur de
// flexion. I = épaisseur³/12 (section rectangulaire de 1 m de profondeur).
export function bendingStiffness(materialId, sectionArea, segLength) {
  const material = getMaterialById(materialId);
  if (!material || segLength === 0) return 0;
  const momentOfInertia = Math.pow(sectionArea, 3) / 12;
  return (material.youngModulus * momentOfInertia) / segLength / BENDING_STIFFNESS_DIVISOR;
}

// Angle de rotation (rad) entre p0→p1 et p1→p2 (0 = aligné). Réutilisé par rupture.js.
export function turningAngle(p0, p1, p2) {
  const e1x = p1.x - p0.x, e1y = p1.y - p0.y;
  const e2x = p2.x - p1.x, e2y = p2.y - p1.y;
  return Math.atan2(e1x * e2y - e1y * e2x, e1x * e2x + e1y * e2y);
}

// Énergie d'un pivot d'extrémité : ½·k·ψ², ψ = angle entre la direction de
// repos (dx,dy) et la direction actuelle du segment E→N.
function endAngle(E, N, dx, dy) {
  const ex = N.x - E.x, ey = N.y - E.y;
  const L = Math.hypot(ex, ey) || 1e-9;
  const ux = ex / L, uy = ey / L;
  return Math.atan2(dx * uy - dy * ux, dx * ux + dy * uy);
}

function addForce(forces, node, fx, fy) {
  if (node.fixed) return;
  const f = forces.get(node.id);
  if (f) {
    f.fx += fx;
    f.fy += fy;
  }
}

// Force = −∇(énergie) par différences finies, distribuée aux nœuds du terme.
function applyTermFD(forces, nodes, energyFn) {
  for (const node of nodes) {
    if (node.fixed || !forces.has(node.id)) continue;
    const ox = node.x;
    node.x = ox + FD_STEP;
    const epx = energyFn();
    node.x = ox - FD_STEP;
    const emx = energyFn();
    node.x = ox;

    const oy = node.y;
    node.y = oy + FD_STEP;
    const epy = energyFn();
    node.y = oy - FD_STEP;
    const emy = energyFn();
    node.y = oy;

    addForce(forces, node, -(epx - emx) / (2 * FD_STEP), -(epy - emy) / (2 * FD_STEP));
  }
}

// Applique tous les ressorts angulaires d'UNE poutre.
export function applyBeamBending(structure, beam, forces) {
  const nodes = beam.nodeIds.map((id) => findNodeById(structure, id));
  if (nodes.some((n) => !n)) return;

  const seg0 = structure.segments.find((s) => s.id === beam.segIds[0]);
  const kTheta = bendingStiffness(beam.materialId, beam.sectionArea, seg0 ? seg0.restLength : 1);
  if (kTheta === 0) return;
  const kPivot = kTheta * JOINT_STIFFNESS_FACTOR;

  // Charnières internes.
  for (let i = 1; i < nodes.length - 1; i++) {
    const p0 = nodes[i - 1], p1 = nodes[i], p2 = nodes[i + 1];
    applyTermFD(forces, [p0, p1, p2], () => 0.5 * kTheta * Math.pow(turningAngle(p0, p1, p2), 2));
  }

  // Pivots d'extrémité (seulement si le bout est un assemblage rigide).
  applyEndIfRigid(structure, beam, forces, kPivot, true);
  applyEndIfRigid(structure, beam, forces, kPivot, false);
}

function applyEndIfRigid(structure, beam, forces, kPivot, atStart) {
  const ids = beam.nodeIds;
  const endId = atStart ? ids[0] : ids[ids.length - 1];
  const nextId = atStart ? ids[1] : ids[ids.length - 2];
  const end = findNodeById(structure, endId);
  const next = findNodeById(structure, nextId);
  if (!end || !next) return;

  const rigid = end.kind === "joint" && (end.fixed || jointBeamCount(structure, endId) >= 2);
  if (!rigid) return;

  // Direction de repos du segment d'extrémité (du bout vers le nœud suivant).
  const rx = next.restX - end.restX;
  const ry = next.restY - end.restY;
  const rl = Math.hypot(rx, ry) || 1e-9;
  const dx = rx / rl, dy = ry / rl;
  applyTermFD(forces, [end, next], () => 0.5 * kPivot * Math.pow(endAngle(end, next, dx, dy), 2));
}
