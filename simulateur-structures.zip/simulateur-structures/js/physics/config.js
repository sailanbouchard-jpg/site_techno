// physics/config.js
// ─────────────────
// Toutes les constantes qui pilotent le COMPORTEMENT physique. Un enseignant
// peut régler ici le "ressenti" sans toucher aux formules.
//
// AMPLIFICATION DE LA DÉFORMATION (objectif : VOIR la physique, pour des
// collégiens). Les vraies poutres se déforment de façon minuscule ; on divise
// donc la raideur réelle par des facteurs choisis UNE FOIS (plus de slider) :
//   - AXIAL_STIFFNESS_DIVISOR : assouplit l'étirement/compression (et stabilise
//     numériquement l'intégration explicite) ;
//   - BENDING_STIFFNESS_DIVISOR : exagère la FLEXION/le flambement, le plus
//     visible pédagogiquement.
// La RÉSISTANCE (seuils de rupture) reste calculée sur la vraie contrainte
// (force/section, moment/module) : casser reste "vrai", seule la déformation
// est exagérée — voir physics/rupture.js.

export const GRAVITY_ACCELERATION = 9.81; // m/s²

// Pas de temps physique fixe (s). Stable aux raideurs assouplies ci-dessous.
export const PHYSICS_DT = 0.0005; // 0,5 ms

// Plafond de pas "rattrapés" par image (anti "spiral of death").
export const MAX_STEPS_PER_FRAME = 200;

// Amortissement appliqué à chaque pas (la vitesse est multipliée par ce
// facteur). Volontairement fort : RELAXATION quasi-statique qui se stabilise
// sans trop osciller. Compromis : assez fort pour borner le sursaut sous
// charge, assez doux pour atteindre l'équilibre (et donc rompre) en quelques
// secondes.
export const VELOCITY_DAMPING_PER_STEP = 0.999;

// Plafond de vitesse d'un nœud (m/s) : garde-fou de sécurité contre une
// divergence numérique extrême (jamais atteint en usage normal, où les
// vitesses restent faibles). N'altère pas la dynamique courante.
export const MAX_NODE_SPEED = 50;

// Masse plancher d'un nœud (kg) : garde-fou numérique (évite F/m avec m=0).
export const MIN_NODE_MASS = 1;

// Une poutre ne rompt que si elle reste au-delà de sa limite pendant AU MOINS
// ce temps (s) : filtre les pics d'effort TRANSITOIRES (au lancement, à un
// choc) pour ne casser que sous une surcharge SOUTENUE — comme la tolérance
// d'un vrai matériau à une sollicitation brève.
export const RUPTURE_PERSIST_TIME = 0.08;

// ── Amplification de la déformation (diviseurs de raideur) ──
export const AXIAL_STIFFNESS_DIVISOR = 150;
export const BENDING_STIFFNESS_DIVISOR = 1;
// Raideur du pivot d'assemblage/encastrement, en fraction de la raideur de
// flexion interne (1 = assemblage bien encastré).
export const JOINT_STIFFNESS_FACTOR = 1.0;

// ── Subdivision des poutres en sous-éléments ──
// ~ un sous-élément par SEGMENT_TARGET_LENGTH mètres, borné (coût ∝ nb total).
export const SEGMENT_TARGET_LENGTH = 2.5; // mètres
export const MIN_SEGMENTS_PER_BEAM = 3;
export const MAX_SEGMENTS_PER_BEAM = 8;

// Imperfection latérale (fraction de la longueur) des nœuds internes à la
// construction : minuscule courbure de départ qui donne au FLAMBEMENT une
// direction définie et reproductible (une poutre parfaitement droite serait en
// équilibre instable). Une vraie asymétrie de chargement domine cette graine.
export const BUCKLING_IMPERFECTION = 0.004;

// Montée progressive de la gravité au lancement (évite l'à-coup à t=0).
export const GRAVITY_RAMP_DURATION = 2.5; // secondes

// ── Charges mobiles (voitures, camions) ──
export const WATTS_PER_HORSEPOWER = 735.5;
export const MAX_VEHICLE_SPEED = 60; // m/s, garde-fou numérique
export const ROLLING_RESISTANCE = 0.015;
