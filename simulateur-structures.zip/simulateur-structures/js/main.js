// main.js
// ───────
// Point d'entrée : initialise une scène vide (maillage prêt), branche l'UI, et
// fait tourner la boucle d'animation (accumulateur de temps fixe + rendu).
// SEUL fichier qui appelle simulationEngine.step().

import { state, MODES } from "./state.js";
import { step } from "./physics/simulationEngine.js";
import { draw } from "./render/renderer.js";
import { initToolbar, updateTimeDisplay, updateStructureWeightDisplay } from "./ui/toolbar.js";
import { initStructureEditor } from "./ui/structureEditor.js";
import { initTestCasePanel } from "./ui/testCasePanel.js";
import { renderInspector } from "./ui/inspector.js";
import { PHYSICS_DT, MAX_STEPS_PER_FRAME } from "./physics/config.js";
import { PIXELS_PER_METER } from "./render/styleConfig.js";

const canvas = document.getElementById("simulation-canvas");
const ctx = canvas.getContext("2d");

let timeAccumulator = 0;
let lastFrameTimestamp = null;

function applyCanvasSizeFromStyleConfig() {
  const root = getComputedStyle(document.documentElement);
  canvas.width = parseInt(root.getPropertyValue("--canvas-width"), 10);
  canvas.height = parseInt(root.getPropertyValue("--canvas-height"), 10);
}

function centerCameraOnCanvas() {
  state.cameraX = canvas.width / 2 / PIXELS_PER_METER;
  state.cameraY = canvas.height / 2 / PIXELS_PER_METER;
}

function resetTimeAccumulator() {
  timeAccumulator = 0;
}

function animationLoop(timestamp) {
  if (lastFrameTimestamp === null) lastFrameTimestamp = timestamp;
  timeAccumulator += (timestamp - lastFrameTimestamp) / 1000;
  lastFrameTimestamp = timestamp;

  let steps = 0;
  while (timeAccumulator >= PHYSICS_DT && steps < MAX_STEPS_PER_FRAME) {
    if (state.mode === MODES.SIMULATION && state.isRunning) {
      step(state.structure, PHYSICS_DT, state.simulationTime);
      state.simulationTime += PHYSICS_DT;
    }
    timeAccumulator -= PHYSICS_DT;
    steps += 1;
  }
  if (steps === MAX_STEPS_PER_FRAME) timeAccumulator = 0;

  draw(ctx, canvas, state);
  updateTimeDisplay();
  updateStructureWeightDisplay();
  requestAnimationFrame(animationLoop);
}

function init() {
  applyCanvasSizeFromStyleConfig();
  centerCameraOnCanvas();
  initToolbar({ onReset: resetTimeAccumulator });
  initStructureEditor(canvas, { onInspect: renderInspector });
  initTestCasePanel();
  renderInspector();
  requestAnimationFrame(animationLoop);
}

init();
