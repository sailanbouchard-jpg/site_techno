// state.js
// ────────
// État central (source unique de vérité) : la structure en cours, l'état de la
// simulation (mode, lecture/pause, temps), et l'état d'interface (outil actif,
// type de poutre courant, masse du poids courant, sélection, vue zoom/pan).
//
// Plus de "facteur de déformation" variable : la déformation est désormais
// RÉELLE dans le monde (amplifiée par des raideurs assouplies fixes, voir
// physics/config.js). Le rendu dessine les positions physiques telles quelles.

import { createStructure } from "./model/Structure.js";
import { BEAM_TYPES } from "./model/materials.js";
import { DEFAULT_ZOOM_LEVEL } from "./render/styleConfig.js";

export const TOOLS = {
  ADD_BEAM: "addBeam",
  ANCHOR: "anchor",
  ADD_WEIGHT: "addWeight",
  ADD_CAR: "addCar",
  ADD_TRUCK: "addTruck",
  DELETE: "delete",
  SELECT: "select",
  PAN: "pan",
};

export const MODES = { EDIT: "edit", SIMULATION: "simulation" };

// Masse par défaut d'un poids posé (kg). L'utilisateur peut l'ajuster ensuite
// dans l'inspecteur du point.
const DEFAULT_WEIGHT_MASS = 8000;

export const state = {
  structure: createStructure(),
  structureSnapshot: null,

  mode: MODES.EDIT,
  isRunning: false,
  simulationTime: 0,

  currentTool: TOOLS.ADD_BEAM,
  currentBeamTypeId: BEAM_TYPES[0].id,
  currentWeightMass: DEFAULT_WEIGHT_MASS,

  // Sélection courante : { type: "beam"|"node"|"vehicle"|null, id }
  selection: { type: null, id: null },

  // Premier point du maillage déjà cliqué pendant le tracé d'une poutre
  // ({ i, j } ou null) — pas un id de nœud, car le joint peut ne pas encore exister.
  pendingBeamFirstGrid: null,

  // Vue (zoom + déplacement). cameraX/Y = point du monde affiché au centre.
  zoomLevel: DEFAULT_ZOOM_LEVEL,
  cameraX: 0,
  cameraY: 0,
};

export function setSelection(type, id) {
  state.selection = { type, id };
}
export function clearSelection() {
  state.selection = { type: null, id: null };
}
export function setTool(tool) {
  state.currentTool = tool;
  state.pendingBeamFirstGrid = null;
}

function restoreFrom(sourceStructure) {
  state.structure = structuredClone(sourceStructure);
  state.simulationTime = 0;
  state.isRunning = false;
  state.mode = MODES.EDIT;
  clearSelection();
  state.pendingBeamFirstGrid = null;
}

// Charge une structure (cas de test ou sauvegarde) : remplace la structure
// courante et prend un instantané pour "Réinitialiser".
export function loadStructure(structure) {
  restoreFrom(structure);
  state.structureSnapshot = structuredClone(structure);
}

// Instantané "tel que conçu", pris juste avant de lancer la simulation.
export function takeStructureSnapshot() {
  state.structureSnapshot = structuredClone(state.structure);
}

export function resetToSnapshot() {
  if (!state.structureSnapshot) {
    state.simulationTime = 0;
    state.isRunning = false;
    state.mode = MODES.EDIT;
    clearSelection();
    state.pendingBeamFirstGrid = null;
    return;
  }
  restoreFrom(state.structureSnapshot);
}
