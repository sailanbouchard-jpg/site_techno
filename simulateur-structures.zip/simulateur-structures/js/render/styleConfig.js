// render/styleConfig.js
// ─────────────────────
// TOUTES les valeurs visuelles du canvas (couleurs, tailles, échelles). Aucune
// couleur/taille de dessin ne doit être écrite en dur ailleurs. N'influe JAMAIS
// sur la physique.

// ── Échelle monde → écran ──
export const PIXELS_PER_METER = 20; // ~40 m × 25 m visibles à zoom ×1

// ── Zoom / déplacement de la vue ──
export const ZOOM_LEVEL_MIN = 1;
export const ZOOM_LEVEL_MAX = 5;
export const DEFAULT_ZOOM_LEVEL = 1;

// ── Maillage (points de construction) ──
export const MESH_POINT_COLOR = "#c4ccd4";
export const MESH_POINT_RADIUS = 2.2;
export const MESH_POINT_HOVER_COLOR = "#2a6f97";
export const MESH_POINT_HOVER_RADIUS = 5;

// ── Nœuds (joints) ──
export const NODE_RADIUS = 5;
export const JOINT_COLOR = "#3a4a58";
export const FIXED_NODE_COLOR = "#555555";
export const NODE_CLICK_RADIUS = 14; // tolérance de clic / d'accrochage au point

// ── Poutres ──
export const BEAM_WIDTH_BASE_PX = 2.5;
export const BEAM_WIDTH_PX_PER_METER_THICKNESS = 52;
export const BEAM_WIDTH_MIN_PX = 3;
export const BEAM_WIDTH_MAX_PX = 18;
export const ELEMENT_SELECTED_WIDTH_BONUS_PX = 2;
export const ELEMENT_CLICK_TOLERANCE = 7;

// ── Code couleur des efforts internes ──
// Compression = bleu, traction = rouge ; l'intensité (du clair au foncé) suit le
// taux de travail. Au repos / quasi nul : gris neutre. La FLEXION, elle, est
// déjà visible par la forme courbée de la poutre.
export const FORCE_COMPRESSION_COLOR = "#2b6cb0";
export const FORCE_COMPRESSION_DARK = "#0c2c4a";
export const FORCE_TENSION_COLOR = "#e24b4a";
export const FORCE_TENSION_DARK = "#5a1111";
export const FORCE_NEUTRAL_COLOR = "#8a949e";
export const CABLE_DASH_PATTERN = [8, 5];

// ── Route (marquage pour charges mobiles) ──
export const ROAD_INDICATOR_GAP_PX = 2;
export const ROAD_INDICATOR_WIDTH_PX = 2;
export const ROAD_INDICATOR_COLOR = "#c9a227";
export const ROAD_INDICATOR_DASH_PATTERN = [4, 4];

// ── Poids posés ──
export const WEIGHT_COLOR = "#3a4a58";
export const WEIGHT_SIZE_PX = 13;
export const WEIGHT_CLICK_TOLERANCE = 14;

// ── Étiquette "% de l'effort de rupture" (au survol/sélection d'une poutre) ──
export const RUPTURE_LABEL_OFFSET_PX = 10;
export const RUPTURE_LABEL_FONT = "10px sans-serif";
export const RUPTURE_LABEL_COLOR = "#5a6472";

// ── Sélection / surbrillance ──
export const SELECTION_COLOR = "#e6a23c";
export const SELECTION_RING_MARGIN = 5;
export const SELECTION_RING_WIDTH = 2;
export const SELECTION_OUTLINE_WIDTH = 2;
export const SELECTION_OUTLINE_DASH = [5, 4];

// ── Symbole d'ancrage (nœud fixe) ──
export const ANCHOR_SYMBOL_WIDTH = 16;
export const ANCHOR_SYMBOL_OFFSET_Y = 8;
export const ANCHOR_HATCH_COUNT = 4;
export const ANCHOR_HATCH_LENGTH = 8;

// ── Flèches (poids / aperçu) ──
export const FORCE_ARROW_HEAD_LENGTH = 8;
export const FORCE_ARROW_LINE_WIDTH = 2;

// ── Charges mobiles (silhouettes voiture / camion, une seule couleur) ──
export const VEHICLE_CAR_COLOR = "#2f6f4f";
export const VEHICLE_TRUCK_COLOR = "#7a3b2e";
export const VEHICLE_CAR_LENGTH_PX = 26;
export const VEHICLE_CAR_HEIGHT_PX = 12;
export const VEHICLE_TRUCK_LENGTH_PX = 40;
export const VEHICLE_TRUCK_HEIGHT_PX = 17;
export const VEHICLE_CLICK_TOLERANCE = 16;
