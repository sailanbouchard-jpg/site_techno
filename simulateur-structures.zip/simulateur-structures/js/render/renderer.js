// render/renderer.js
// ──────────────────
// Dessine l'état courant. LECTURE SEULE, aucune formule de mouvement. Les
// poutres sont tracées SUBDIVISÉES (polyligne passant par leurs nœuds
// internes) : leur COURBURE de flexion est donc directement visible. Chaque
// sous-élément est coloré selon son effort axial (compression = bleu, traction
// = rouge, intensité = taux de travail).

import { findNodeById, canAddBeam } from "../model/Structure.js";
import { getMaterialById } from "../model/materials.js";
import { gridToWorld } from "../model/mesh.js";
import { computeSegmentForce } from "../physics/springForces.js";
import { drawAnchorSymbol, clamp } from "./canvasUtils.js";
import { worldToBasePixels, getViewTranslation } from "./displayTransform.js";
import { drawMesh } from "./grid.js";
import { drawVehicle } from "./vehicleRenderer.js";
import {
  NODE_RADIUS, JOINT_COLOR, FIXED_NODE_COLOR,
  BEAM_WIDTH_BASE_PX, BEAM_WIDTH_PX_PER_METER_THICKNESS, BEAM_WIDTH_MIN_PX, BEAM_WIDTH_MAX_PX,
  ELEMENT_SELECTED_WIDTH_BONUS_PX,
  FORCE_COMPRESSION_COLOR, FORCE_COMPRESSION_DARK, FORCE_TENSION_COLOR, FORCE_TENSION_DARK, FORCE_NEUTRAL_COLOR,
  CABLE_DASH_PATTERN, ROAD_INDICATOR_COLOR, ROAD_INDICATOR_WIDTH_PX, ROAD_INDICATOR_DASH_PATTERN,
  WEIGHT_COLOR, WEIGHT_SIZE_PX,
  SELECTION_COLOR, SELECTION_RING_MARGIN, SELECTION_RING_WIDTH, SELECTION_OUTLINE_WIDTH, SELECTION_OUTLINE_DASH,
} from "./styleConfig.js";

export function draw(ctx, canvas, state) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const view = { zoomLevel: state.zoomLevel, cameraX: state.cameraX, cameraY: state.cameraY, canvasWidth: canvas.width, canvasHeight: canvas.height };

  ctx.save();
  const t = getViewTranslation(view);
  ctx.translate(t.x, t.y);
  ctx.scale(view.zoomLevel, view.zoomLevel);

  drawMesh(ctx, state.hoverGrid);

  for (const beam of state.structure.beams) drawBeam(ctx, state, beam);
  for (const node of state.structure.nodes) if (node.kind === "joint") drawJoint(ctx, state, node);
  for (const load of state.structure.loads) drawWeight(ctx, state, load);
  for (const vehicle of state.structure.mobileLoads) drawVehicle(ctx, vehicle, state.structure, isSel(state, "vehicle", vehicle.id));

  drawPreview(ctx, state);
  ctx.restore();
}

function beamWidth(beam, selected) {
  const raw = BEAM_WIDTH_BASE_PX + beam.sectionArea * BEAM_WIDTH_PX_PER_METER_THICKNESS;
  return clamp(raw, BEAM_WIDTH_MIN_PX, BEAM_WIDTH_MAX_PX) + (selected ? ELEMENT_SELECTED_WIDTH_BONUS_PX : 0);
}

function drawBeam(ctx, state, beam) {
  const selected = isSel(state, "beam", beam.id);
  const material = getMaterialById(beam.materialId);
  const width = beamWidth(beam, selected);

  ctx.save();
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (beam.isCable) ctx.setLineDash(CABLE_DASH_PATTERN);

  for (const segId of beam.segIds) {
    const seg = state.structure.segments.find((s) => s.id === segId);
    if (!seg) continue;
    const a = findNodeById(state.structure, seg.nodeAId);
    const b = findNodeById(state.structure, seg.nodeBId);
    if (!a || !b) continue;
    const pa = worldToBasePixels(a), pb = worldToBasePixels(b);
    const { magnitude } = computeSegmentForce(a, b, seg, beam.isCable);
    ctx.strokeStyle = forceColor(magnitude, beam, material);
    ctx.beginPath();
    ctx.moveTo(pa.x, pa.y);
    ctx.lineTo(pb.x, pb.y);
    ctx.stroke();
  }
  ctx.restore();

  if (beam.isRoad) drawRoadMarking(ctx, state, beam);
  if (selected) drawBeamSelection(ctx, state, beam);
}

// Couleur d'un sous-élément selon son effort axial signé (>0 traction, <0
// compression) : du gris neutre (peu sollicité) vers la couleur foncée (proche
// de la rupture). Taux de travail calculé sur les VRAIES résistances.
function forceColor(magnitude, beam, material) {
  if (!material || Math.abs(magnitude) < 1) return FORCE_NEUTRAL_COLOR;
  const stress = Math.abs(magnitude) / beam.sectionArea;
  const limit = magnitude >= 0 ? material.tensileStrength : material.compressiveStrength;
  const util = clamp(limit > 0 ? stress / limit : 0, 0, 1);
  const base = magnitude >= 0 ? FORCE_TENSION_COLOR : FORCE_COMPRESSION_COLOR;
  const dark = magnitude >= 0 ? FORCE_TENSION_DARK : FORCE_COMPRESSION_DARK;
  return util < 0.5 ? hexLerp(FORCE_NEUTRAL_COLOR, base, util * 2) : hexLerp(base, dark, (util - 0.5) * 2);
}

function polyline(ctx, state, beam) {
  ctx.beginPath();
  let first = true;
  for (const id of beam.nodeIds) {
    const n = findNodeById(state.structure, id);
    if (!n) continue;
    const p = worldToBasePixels(n);
    if (first) { ctx.moveTo(p.x, p.y); first = false; } else ctx.lineTo(p.x, p.y);
  }
  ctx.stroke();
}

function drawRoadMarking(ctx, state, beam) {
  ctx.save();
  ctx.strokeStyle = ROAD_INDICATOR_COLOR;
  ctx.lineWidth = ROAD_INDICATOR_WIDTH_PX;
  ctx.setLineDash(ROAD_INDICATOR_DASH_PATTERN);
  ctx.lineCap = "round";
  polyline(ctx, state, beam);
  ctx.restore();
}

function drawBeamSelection(ctx, state, beam) {
  ctx.save();
  ctx.strokeStyle = SELECTION_COLOR;
  ctx.lineWidth = SELECTION_OUTLINE_WIDTH;
  ctx.setLineDash(SELECTION_OUTLINE_DASH);
  polyline(ctx, state, beam);
  ctx.restore();
}

function drawJoint(ctx, state, node) {
  const p = worldToBasePixels(node);
  ctx.beginPath();
  ctx.arc(p.x, p.y, NODE_RADIUS, 0, Math.PI * 2);
  ctx.fillStyle = node.fixed ? FIXED_NODE_COLOR : JOINT_COLOR;
  ctx.fill();
  if (node.fixed) drawAnchorSymbol(ctx, p.x, p.y, FIXED_NODE_COLOR);
  if (isSel(state, "node", node.id)) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, NODE_RADIUS + SELECTION_RING_MARGIN, 0, Math.PI * 2);
    ctx.strokeStyle = SELECTION_COLOR;
    ctx.lineWidth = SELECTION_RING_WIDTH;
    ctx.stroke();
  }
}

// Poids posé : un bloc suspendu sous le joint. Taille croissant avec la masse.
function drawWeight(ctx, state, load) {
  const node = findNodeById(state.structure, load.jointId);
  if (!node) return;
  const p = worldToBasePixels(node);
  const size = WEIGHT_SIZE_PX * clamp(Math.sqrt(load.mass / 8000), 0.6, 2.2);
  const top = p.y + NODE_RADIUS + 3;

  ctx.save();
  ctx.strokeStyle = WEIGHT_COLOR;
  ctx.fillStyle = WEIGHT_COLOR;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(p.x, p.y);
  ctx.lineTo(p.x, top);
  ctx.stroke();
  ctx.fillRect(p.x - size / 2, top, size, size * 0.8);
  ctx.restore();

  if (isSel(state, "load", load.id)) {
    ctx.save();
    ctx.strokeStyle = SELECTION_COLOR;
    ctx.lineWidth = SELECTION_OUTLINE_WIDTH;
    ctx.setLineDash(SELECTION_OUTLINE_DASH);
    ctx.strokeRect(p.x - size / 2 - 2, top - 2, size + 4, size * 0.8 + 4);
    ctx.restore();
  }
}

// Aperçu élastique : du premier point cliqué vers le point survolé. Vert si
// autorisé, rouge si une poutre occupe déjà ce chemin.
function drawPreview(ctx, state) {
  if (!state.pendingBeamFirstGrid || !state.hoverGrid) return;
  const a = state.pendingBeamFirstGrid, b = state.hoverGrid;
  const pa = worldToBasePixels(gridToWorld(a.i, a.j));
  const pb = worldToBasePixels(gridToWorld(b.i, b.j));
  const ok = canAddBeam(state.structure, a, b).ok;

  ctx.save();
  ctx.strokeStyle = ok ? "#2f8f4f" : "#d64545";
  ctx.lineWidth = 2.5;
  ctx.setLineDash([6, 5]);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(pa.x, pa.y);
  ctx.lineTo(pb.x, pb.y);
  ctx.stroke();
  ctx.restore();
}

function hexLerp(c1, c2, t) {
  const a = parseInt(c1.slice(1), 16), b = parseInt(c2.slice(1), 16);
  const r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
  const g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
  const bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
  return `rgb(${r},${g},${bl})`;
}

function isSel(state, type, id) {
  return state.selection.type === type && state.selection.id === id;
}
