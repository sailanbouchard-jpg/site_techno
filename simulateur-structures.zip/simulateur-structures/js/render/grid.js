// render/grid.js
// ──────────────
// Dessine le MAILLAGE : la grille de points sur lesquels on construit (façon
// "jeu de pont"). Met aussi en évidence le point survolé (point fantôme) vers
// lequel le prochain clic va s'accrocher. LECTURE SEULE.
//
// Dessine en "pixels de base" : appelé dans le contexte déjà transformé par le
// zoom (renderer.js), donc tailles et positions suivent le zoom.

import { listMeshPoints } from "../model/mesh.js";
import { worldToBasePixels } from "./displayTransform.js";
import { MESH_POINT_COLOR, MESH_POINT_RADIUS, MESH_POINT_HOVER_COLOR, MESH_POINT_HOVER_RADIUS } from "./styleConfig.js";

export function drawMesh(ctx, hoverGrid) {
  ctx.save();
  ctx.fillStyle = MESH_POINT_COLOR;
  for (const p of listMeshPoints()) {
    const px = worldToBasePixels(p);
    ctx.beginPath();
    ctx.arc(px.x, px.y, MESH_POINT_RADIUS, 0, Math.PI * 2);
    ctx.fill();
  }

  // Point fantôme (survol) : montre où le clic va s'accrocher.
  if (hoverGrid) {
    const px = worldToBasePixels(hoverGrid);
    ctx.fillStyle = MESH_POINT_HOVER_COLOR;
    ctx.beginPath();
    ctx.arc(px.x, px.y, MESH_POINT_HOVER_RADIUS, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
